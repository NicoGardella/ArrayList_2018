﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Torneo<T> where T : Equipo
    {
        List<T> equipos;
        string nombre;
        public static bool operator ==(Torneo<T> t, Equipo e)
        {
            if (t.equipos.Contains(e))
                return true;
            return false;
        }
        public static bool operator !=(Torneo<T> t, Equipo e)
        {
            return !(t == e);
        }
        public static Torneo<T> operator +(Torneo<T> t, T e)
        {
            if (t != e)
            {
                t.equipos.Add(e);
            }
            return t;
        }
        public string Mostrar()
        {
            return "";
        }
        private string CalcularPartido(T e1, T e2)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("[{0}][{1}]-[{2}][{3}]", e1.nombre, new Random().Next(0, 10), new Random().Next(0, 10), e2.nombre);
            return sb.ToString();
        }
        public string JugarPartido
        {
            get
            {
                T e1 = this.equipos[new Random().Next(0, this.equipos.Count)];
                T e2;
                do
                {
                    e2 = this.equipos[new Random().Next(0, this.equipos.Count)];
                }
                while (e1 == e2);
                return CalcularPartido(e1, e2);
            }
        }
    }
}
