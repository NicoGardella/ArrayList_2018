﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int legajo;

        public override bool Equals(object obj)
        {
            if ((this.GetType() == obj.GetType()) && ((this.DNI == ((Universitario)(obj)).DNI) || (this.legajo == ((Universitario)(obj)).legajo)))
            {
                return true;
            }
            return false;
        }
    }
}
